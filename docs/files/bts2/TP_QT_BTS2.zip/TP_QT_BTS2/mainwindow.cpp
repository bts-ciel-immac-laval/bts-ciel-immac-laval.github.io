#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    this->setWindowTitle("TP QT BTS 2");

    // Exercice 1
    connect(ui->btnReduire, SIGNAL(clicked(bool)), this, SLOT(showMinimized()));

    // Exercice 2
    ui->comboChoix->addItem("Choix 1");
    ui->comboChoix->addItem("Choix 2");
    ui->comboChoix->addItem("Choix 3");

    // Exercice 3
    connect(ui->radioGris, SIGNAL(clicked(bool)), this, SLOT(changeBackground()));
    connect(ui->radioMagnifique, SIGNAL(clicked(bool)), this, SLOT(changeBackground()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Exercice 3
void MainWindow::changeBackground() {
    // Utilisation du debug pour afficher qui a été cliqué
    qDebug() << (ui->radioGris->isChecked() ? "Gris" : "Magnifique");

    if (ui->radioGris->isChecked()) {
        this->setStyleSheet("#centralwidget { background-image: none; }");
    }
    else {
        // Triche pour étirer l'image (source: https://forum.qt.io/topic/40151/solved-scaled-background-image-using-stylesheet/10)
        this->setStyleSheet("#centralwidget { border-image: url(:/images/4091164.jpg) 0 0 0 0 stretch stretch; }");
    }
}

// Exercice 4
void MainWindow::changeWindowTitle(QString title) {
    this->setWindowTitle(title);
}
