#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    qnam = new QNetworkAccessManager;
    qnr = nullptr;

    connect(ui->guessButton, SIGNAL(clicked(bool)), this, SLOT(launchHTTPRequest()));
}

MainWindow::~MainWindow()
{
    delete qnr;
    delete qnam;
    delete ui;
}

void MainWindow::launchHTTPRequest() {
    QString url("https://pokeapi.co/api/v2/pokemon-species/");

    if (ui->numberTextbox->text() != "") {

        url += ui->numberTextbox->text();

        if (qnr != nullptr) {
            disconnect(qnr, SIGNAL(finished()), this, SLOT(manageHTTPAnswer()));
            delete qnr;
        }

        qnr = qnam->get(QNetworkRequest(QUrl(url)));
        connect(qnr, SIGNAL(finished()), this, SLOT(manageHTTPAnswer()));
        connect(qnr, SIGNAL(errorOccurred(QNetworkReply::NetworkError)), this, SLOT(manageHTTPErrors(QNetworkReply::NetworkError)));
    }
}

void MainWindow::manageHTTPAnswer() {
    QByteArray data = qnr->readAll();
    QJsonDocument doc = QJsonDocument::fromJson(data);
    QJsonArray names;
    if (!doc.isNull()) {
        QJsonObject json = doc.object();
        names = json["names"].toArray();
        for (int i = 0; i < names.size(); i++) {
            if (names[i].toObject()["language"].toObject()["name"].toString() == "fr") {
                ui->nameLabel->setText(names[i].toObject()["name"].toString());
                break;
            }
        }
    }
    else {
        qDebug() << "Erreur :  JSON mal formé :(";
    }
}

void MainWindow::manageHTTPErrors(QNetworkReply::NetworkError error) {
    qDebug() << error;
}
