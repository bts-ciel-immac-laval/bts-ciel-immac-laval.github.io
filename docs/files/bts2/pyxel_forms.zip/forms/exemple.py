import pyxel
from forms import *

class App:
    def __init__(self):
        pyxel.init(128, 128)
        pyxel.mouse(True)
        self.form = Form([
            Label("-= Titre du formulaire =-", align = Alignable.ALIGN_CENTER),
            Label("Checkbox :", 14),
            Checkbox("checkbox1", "Option 1"),
            Checkbox("checkbox2", "Option 2", True),
            Label("Radio :", 14),
            Radio("radio1", [
                { "label" : "Option 3", "value" : "trois"}, 
                { "label" : "Option 4", "value" : 4}, 
                { "label" : "Option 5", "value" : "cinq"}
            ], 2),
            Label("Textbox :", 14),
            Textbox("login", "test"),
            Label("Textbox (password) :", 14),
            Textbox("password", "test", password = True),
            Button("Valider", self.print)
        ])
        pyxel.run(self.update, self.draw)

    def update(self):
        self.form.update()
        
    def print(self) :
        self.form.print()

    def draw(self):
        pyxel.cls(0)
        self.form.draw()

App()