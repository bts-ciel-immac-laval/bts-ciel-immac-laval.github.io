#include "devoir.h"

int main(int argc, char ** argv) {
    int sensors[20];
    char filePath[50];
    struct values values;

    checkParameters(argc);
    int sensorsCount = listSensors(argc, argv, sensors);
    setFilePath(argc, argv, filePath);
    for (int i = 0; i < sensorsCount; i++) {
        values = getValuesFromSensorFile(sensors[i]);
        appendSensorValues(filePath, values);
    }
    return 0;
}