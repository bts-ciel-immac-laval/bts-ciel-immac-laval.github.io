#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


/**
 * @brief Interrompt le programme et affiche un message d'erreur s'il y a trop ou pas assez de paramètres sur la ligne de commande
 * 
 * @param argc le nombre de paramètres sur la ligne de commande
 */
void checkParameters(int argc) {
    if (argc < 3) {
        puts("Pas suffisamment  de paramètres");
        exit(-1);
    }
    if (argc > 23) {
        puts("Trop de paramètres");
        exit(-2);
    }
}
/**
 * @brief Récupère la liste des capteurs sur la ligne de commande
 * 
 * @param argc Le nombre de paramètres sur la ligne de commande
 * @param argv Les paramètres sur la ligne de commande
 * @param sensors (sortie) La liste des capteurs
 * @return int Le nombre capteurs
 */

int listSensors(int argc, char** argv, int * sensors) {
    int sensorsCount = 0;
    int count = 0;
    for (int i = 1; i < argc && sensorsCount < 20; i++) {
        if (strcmp(argv[i], "-i") == 0) {
            count = 1;
        }
        else if (argv[i][0] == '-') {
            count = 0;
        }
        else if (count == 1) {
            sensors[sensorsCount++] = atoi(argv[i]);
        }
    }
    if (sensorsCount == 0) {
        exit(-3);
    }
    return sensorsCount;
}

/**
 * @brief Crée le fichier filePath ou le vide s'il existe.
 * 
 * @param filePath Le chemin du fichier
 */
void emptyFile(char * filePath) {
    FILE * fichier = NULL;
    
    fichier = fopen(filePath, "w");
    
    if (fichier == NULL) {
        printf("Problème lors de la création du fichier %s\n", filePath);
        exit(-4);
    }

    fclose(fichier);
}

/**
 * @brief Récupère le chemin du fichier .csv sur la ligne de commande s'il est présent 
 *        ou génère le nom du fichier s'il est absent.
 * 
 * @param argc Le nombre de paramètres sur la ligne de commande
 * @param argv Les paramètres sur la ligne de commande
 * @param filePath (sortie) Le chemin du fichier lu ou généré
 */
void setFilePath(int argc, char** argv, char * filePath) {
    for (int i = 1; i < argc - 1; i++) {
        if (strcmp(argv[i], "-o") == 0) {
            strcpy(filePath, argv[i + 1]);
            return;
        }
    }
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(filePath, "%04d%02d%02d.csv", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
    emptyFile(filePath);
}

/**
 * @brief Retourne la plus petite valeur contenue dans le tableau
 * 
 * @param tab Le tableau de valeurs
 * @return float La valeur minimale
 */
float getMinimum(float * tab) {
    float min = tab[0];
    for (int i = 1; i < 1440; i++) {
        if (tab[i] < min) {
            min = tab[i];
        }
    }
    return min;
}

/**
 * @brief Retourne la plus grande valeur contenue dans le tableau
 * 
 * @param tab Le tableau de valeurs
 * @return float La valeur maximale
 */
float getMaximum(float * tab) {
    float max = tab[0];
    for (int i = 1; i < 1440; i++) {
        if (tab[i] > max) {
            max = tab[i];
        }
    }
    return max;
}

float getMean(float * tab) {
    float mean = 0;
    for (int i = 0; i < 1440; i++) {
        mean += tab[i];
    }
    return mean / 1440;
}


struct values {
    int sensor;
    float min, mean, max;
};

/**
 * @brief Lit le fichier, extrait les valeurs puis isole le minimum, le maximum et calcule la moyenne des valeurs.
 * 
 * @param sensor Le numéro du capteur
 * @return struct values Les valeurs à exporter pour le capteur
 */
struct values getValuesFromSensorFile(int sensor) {
    char filePath[50], ligne[10];
    FILE * fichier = NULL;
    struct values result = {  sensor };
    float values[1440];
    int i = 0;
    
    sprintf(filePath, "sensors/%d.csv", sensor);
    fichier = fopen(filePath, "r");
    
    if (fichier == NULL) {
        printf("Problème lors de l'ouverture du fichier %s\n", filePath);
        return result;
    }

    while (fgets(ligne, 10, fichier) != NULL) {
        values[i++] = atof(ligne);
    }

    result.min = getMinimum(values);
    result.mean = getMean(values);
    result.max = getMaximum(values);

    fclose(fichier);

    return result;
}
/**
 * @brief Ajoute une ligne de valeurs dans le fichier filepath
 * 
 * @param filePath Le fichier à ouvrir pour modification
 * @param sensorValues Les valeurs à ajouter
 */
void appendSensorValues(char * filePath, struct values sensorValues) {
    
    FILE * fichier = NULL;
    
    fichier = fopen(filePath, "a");
    
    if (fichier == NULL) {
        printf("Problème lors de l'ouverture du fichier %s\n", filePath);
        exit(-5);
    }

    fprintf(fichier, "%d;%.2f;%.2f;%.2f\n", sensorValues.sensor, sensorValues.min, sensorValues.mean, sensorValues.max);

    fclose(fichier);
}