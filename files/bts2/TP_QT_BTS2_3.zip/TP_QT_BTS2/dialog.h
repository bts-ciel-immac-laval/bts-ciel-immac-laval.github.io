#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QGraphicsScene>
#include <QGraphicsRectItem>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();

public slots:
    void setShapeWidth(int);
    void setShapeHeight(int);
    void changeFigure(QString);

private:
    Ui::Dialog *ui;
    QGraphicsRectItem * rectangle;
    QGraphicsEllipseItem * ellipse;
};

#endif // DIALOG_H
