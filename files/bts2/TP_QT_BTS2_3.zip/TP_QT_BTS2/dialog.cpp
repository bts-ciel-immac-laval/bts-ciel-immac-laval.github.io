#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);

    // Création de la scène
    QGraphicsScene * scene = new QGraphicsScene(ui->graphicsView);
    scene->setSceneRect(0, 0, 571, 401);
    ui->graphicsView->setScene(scene);

    // Création des figures
    rectangle = scene->addRect(10, 10, 80, 50);
    ellipse = scene->addEllipse(10, 10, 80, 50);
    ellipse->hide();

    // Gestion du changement de figure
    connect(ui->figureComboBox, SIGNAL(currentTextChanged(QString)), this, SLOT(changeFigure(QString)));

    // Gestion des sliders
    ui->horizontalSlider->setValue(80);
    ui->verticalSlider->setValue(50);
    connect(ui->horizontalSlider, SIGNAL(valueChanged(int)), this, SLOT(setShapeWidth(int)));
    connect(ui->verticalSlider, SIGNAL(valueChanged(int)), this, SLOT(setShapeHeight(int)));
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::setShapeWidth(int width) {
    QRectF r = rectangle->rect();
    r.setWidth(width);
    rectangle->setRect(r);
    ellipse->setRect(r);
}

void Dialog::setShapeHeight(int height) {
    QRectF r = rectangle->rect();
    r.setHeight(height);
    rectangle->setRect(r);
    ellipse->setRect(r);
}

void Dialog::changeFigure(QString figure) {
    if (figure == "Rectangle") {
        rectangle->show();
        ellipse->hide();
    }
    else {
        rectangle->hide();
        ellipse->show();
    }
}

